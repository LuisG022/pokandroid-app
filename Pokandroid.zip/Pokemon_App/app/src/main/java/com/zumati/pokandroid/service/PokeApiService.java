package com.zumati.pokandroid.service;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import com.zumati.pokandroid.models.PokeApiResponse;
import com.zumati.pokandroid.models.Pokemon;

public interface PokeApiService {
    @GET("pokemon")
    Call<PokeApiResponse> getPokemonList(@Query("limit") int limit, @Query("offset") int offset);

    @GET("pokemon/{id}")
    Call<Pokemon> getPokemonInfo(@Path("id") int id);
}